¡Hola, bienvenido/a!

Primero que nada, gracias por visitar mi repositorio :D

Éste repositorio fue creado con el fin de permanecer en el tiempo y recordarlos en un futuro.
Tambíen fueron subidos pensando en que puede servirle a personas que deseen introducirse al Lenguaje Python.

¡Espero les sirva de ayuda!

Estudiante Analista Programador en CFT INACAP Los Ángeles (2021)