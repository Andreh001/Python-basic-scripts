#print()
#print("---------------")
#print("   Opciones")
#print()
#print(" 1. Decir hola")
#print()
#print("---------------")
#print()
#opcion = int(input("Ingrese una opcion: "))
#if opcion == 1:
#    print("Hola mundo")
#else:
#    print("Error")

numero1 = int(input("Ingrese el primer numero: "))
numero2 = int(input("Ingrese el segundo numero: "))
suma = numero1 + numero2
print(suma)